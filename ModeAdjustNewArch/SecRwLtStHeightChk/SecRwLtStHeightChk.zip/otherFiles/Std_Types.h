/* Copyright 2018 The MathWorks, Inc. */

/*
 * File: Std_Types.h
 *
 * Definitions for AUTOSAR Standard Types
 *
 * This file contains stub implementations of the AUTOSAR Standard Types.
 * The stub implementations can be used for testing the generated code in
 * Simulink, for example, in SIL/PIL simulations of the component under
 * test. Note that this file should be replaced with an appropriate RTE
 * file when deploying the generated code outside of Simulink.
 */

#ifndef Std_Types_h
#define Std_Types_h
#include "Compiler.h"
#include "Platform_Types.h"

/* define Std_ReturnType */
typedef uint8 Std_ReturnType;


#endif /* Std_Types_h */ 
