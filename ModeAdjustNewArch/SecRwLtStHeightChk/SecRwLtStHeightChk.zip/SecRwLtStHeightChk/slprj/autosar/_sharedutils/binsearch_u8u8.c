/*
 * File: binsearch_u8u8.c
 *
 * Code generated for Simulink model 'SecRwLtStHeightChk'.
 *
 * Model version                  : V2.0.0
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Aug 31 15:59:24 2023
 */

#include "rtwtypes.h"
#include "binsearch_u8u8.h"

uint8 binsearch_u8u8(uint8 u, const uint8 bp[], uint32 startIndex,
  uint32 maxIndex)
{
  uint32 iRght;
  uint32 iLeft;
  uint32 bpIdx;

  /* Binary Search */
  bpIdx = startIndex;
  iLeft = 0U;
  iRght = maxIndex;
  while (iRght - iLeft > 1U) {
    if (u < bp[bpIdx]) {
      iRght = bpIdx;
    } else {
      iLeft = bpIdx;
    }

    bpIdx = (iRght + iLeft) >> 1U;
  }

  return (uint8)iLeft;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
