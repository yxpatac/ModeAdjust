/*
 * File: binsearch_u8u16.h
 *
 * Code generated for Simulink model 'SecRwLtStHeightChk'.
 *
 * Model version                  : V2.0.0
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Aug 31 15:59:24 2023
 */

#ifndef SHARE_binsearch_u8u16
#define SHARE_binsearch_u8u16
#include "rtwtypes.h"

extern uint8 binsearch_u8u16(uint16 u, const uint16 bp[], uint32
  startIndex, uint32 maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
