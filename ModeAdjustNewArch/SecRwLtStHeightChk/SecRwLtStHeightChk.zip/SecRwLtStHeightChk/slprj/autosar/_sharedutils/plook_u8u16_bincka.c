/*
 * File: plook_u8u16_bincka.c
 *
 * Code generated for Simulink model 'SecRwLtStHeightChk'.
 *
 * Model version                  : V2.0.0
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Aug 31 15:59:24 2023
 */

#include "rtwtypes.h"
#include "binsearch_u8u16.h"
#include "plook_u8u16_bincka.h"

uint8 plook_u8u16_bincka(uint16 u, const uint16 bp[], uint32 maxIndex)
{
  uint8 bpIndex;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u <= bp[0U]) {
    bpIndex = 0U;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u8u16(u, bp, maxIndex >> 1U, maxIndex);
  } else {
    bpIndex = (uint8)maxIndex;
  }

  return bpIndex;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
