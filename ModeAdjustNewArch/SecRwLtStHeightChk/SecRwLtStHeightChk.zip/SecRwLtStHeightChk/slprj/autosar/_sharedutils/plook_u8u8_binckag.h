/*
 * File: plook_u8u8_binckag.h
 *
 * Code generated for Simulink model 'SecRwLtStHeightChk'.
 *
 * Model version                  : V2.0.0
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Aug 31 15:59:24 2023
 */

#ifndef SHARE_plook_u8u8_binckag
#define SHARE_plook_u8u8_binckag
#include "rtwtypes.h"

extern uint8 plook_u8u8_binckag(uint8 u, const uint8 bp[], uint32
  maxIndex);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
