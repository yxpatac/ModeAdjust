/*
 * File: SecRwLtStHeightChk.h
 *
 * Code generated for Simulink model 'SecRwLtStHeightChk'.
 *
 * Model version                  : V2.0.0
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Aug 31 16:06:59 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SecRwLtStHeightChk_h_
#define RTW_HEADER_SecRwLtStHeightChk_h_
#ifndef SecRwLtStHeightChk_COMMON_INCLUDES_
# define SecRwLtStHeightChk_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "Rte_SecRwLtStHeightChk.h"
#endif                                 /* SecRwLtStHeightChk_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */

/* Block signals (default storage) */
typedef struct tag_B_SecRwLtStHeightChk_T {
  uint8 Prelookup;                     /* '<S9>/Prelookup' */
  uint8 MultiportSwitch_i;             /* '<S4>/Multiport Switch' */
} B_SecRwLtStHeightChk_T;

/* Block states (default storage) for system '<Root>' */
typedef struct tag_DW_SecRwLtStHeightChk_T {
  boolean UnitDelay_DSTATE;            /* '<S6>/Unit Delay' */
  boolean UnitDelay1_DSTATE;           /* '<S6>/Unit Delay1' */
  boolean UnitDelay2_DSTATE;           /* '<S6>/Unit Delay2' */
} DW_SecRwLtStHeightChk_T;

/* Block signals (default storage) */
extern B_SecRwLtStHeightChk_T SecRwLtStHeightChk_B;

/* Block states (default storage) */
extern DW_SecRwLtStHeightChk_T SecRwLtStHeightChk_DW;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SecRwLtStHeightChk'
 * '<S1>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys'
 * '<S2>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Init'
 * '<S3>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem'
 * '<S4>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/HeightCalcL'
 * '<S5>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/HeightIndexSelect'
 * '<S6>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/Subsystem'
 * '<S7>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/Subsystem1'
 * '<S8>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/Subsystem2'
 * '<S9>'   : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/Subsystem3'
 * '<S10>'  : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/Subsystem/LyL'
 * '<S11>'  : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/Subsystem/RecvL'
 * '<S12>'  : 'SecRwLtStHeightChk/SecRwLtStHeightChk_Cal_sys/Subsystem/Subsystem/VIPL'
 */
#endif                                 /* RTW_HEADER_SecRwLtStHeightChk_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
