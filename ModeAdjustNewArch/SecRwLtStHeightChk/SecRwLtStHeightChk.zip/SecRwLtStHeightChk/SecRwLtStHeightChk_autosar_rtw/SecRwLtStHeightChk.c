/*
 * File: SecRwLtStHeightChk.c
 *
 * Code generated for Simulink model 'SecRwLtStHeightChk'.
 *
 * Model version                  : V2.0.0
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Aug 31 16:06:59 2023
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SecRwLtStHeightChk.h"
#include "plook_u8u16_bincka.h"
#include "plook_u8u8_binckag.h"

/* Exported data definition */

/* Definition for custom storage class: FileScope */
static uint8 HeightIndexL[7] = { 155U, 160U, 165U, 170U, 175U, 180U, 185U } ;

/* Block signals (default storage) */
B_SecRwLtStHeightChk_T SecRwLtStHeightChk_B;

/* Block states (default storage) */
DW_SecRwLtStHeightChk_T SecRwLtStHeightChk_DW;

/* Model step function */
void SecRwLtStHeightChk_Cal()
{
  uint16 tmpRead;
  uint16 tmpRead_0;
  uint32 tmpRead_1;
  uint8 tmpRead_2;
  boolean rtb_RelationalOperator_hy;
  boolean rtb_RelationalOperator_j;
  boolean rtb_RelationalOperator_c;
  boolean rtb_LogicalOperator4;

  /* Inport: '<Root>/IfVeSMSuSecRwLtStPassHeight_Val' */
  Rte_Read_IfVeSMSuSecRwLtStPassHeight_Val(&tmpRead_2);

  /* Inport: '<Root>/StNumFlg_Is4s' */
  Rte_Read_StNumFlg_Is4s(&rtb_LogicalOperator4);

  /* Inport: '<Root>/modestate32_Val' */
  Rte_Read_modestate32_Val(&tmpRead_1);

  /* Inport: '<Root>/IfVeSMSuSecRwLtStHdrstUpwdDnwdPos_Val' */
  Rte_Read_IfVeSMSuSecRwLtStHdrstUpwdDnwdPos_Val(&tmpRead_0);

  /* Inport: '<Root>/IfVeSMSuSecRwLtStBkReclnUpwdDnwdPos_Val' */
  Rte_Read_IfVeSMSuSecRwLtStBkReclnUpwdDnwdPos_Val(&tmpRead);

  /* Outputs for Function Call SubSystem: '<Root>/SecRwLtStHeightChk_Cal_sys' */
  /* RelationalOperator: '<S10>/Relational Operator' incorporates:
   *  Constant: '<S10>/Constant'
   *  S-Function (sfix_bitop): '<S10>/Bitwise Operator'
   *  SignalConversion: '<S1>/TmpLatchAtmodestate32_Val_readOutport1'
   */
  rtb_RelationalOperator_hy = ((tmpRead_1 & 8192U) > 0U);

  /* RelationalOperator: '<S11>/Relational Operator' incorporates:
   *  Constant: '<S11>/Constant'
   *  S-Function (sfix_bitop): '<S11>/Bitwise Operator'
   *  SignalConversion: '<S1>/TmpLatchAtmodestate32_Val_readOutport1'
   */
  rtb_RelationalOperator_j = ((tmpRead_1 & 1024U) > 0U);

  /* RelationalOperator: '<S12>/Relational Operator' incorporates:
   *  Constant: '<S12>/Constant'
   *  S-Function (sfix_bitop): '<S12>/Bitwise Operator'
   *  SignalConversion: '<S1>/TmpLatchAtmodestate32_Val_readOutport1'
   */
  rtb_RelationalOperator_c = ((tmpRead_1 & 512U) > 0U);

  /* Logic: '<S6>/Logical Operator4' incorporates:
   *  Logic: '<S6>/Logical Operator'
   *  Logic: '<S6>/Logical Operator1'
   *  Logic: '<S6>/Logical Operator2'
   *  Logic: '<S6>/Logical Operator3'
   *  Logic: '<S6>/Logical Operator5'
   *  Logic: '<S6>/Logical Operator6'
   *  Logic: '<S6>/Logical Operator7'
   *  SignalConversion: '<S1>/TmpLatchAtStNumFlg_Is4s_readOutport1'
   *  UnitDelay: '<S6>/Unit Delay'
   *  UnitDelay: '<S6>/Unit Delay1'
   *  UnitDelay: '<S6>/Unit Delay2'
   */
  rtb_LogicalOperator4 = (rtb_LogicalOperator4 && ((rtb_RelationalOperator_hy &&
    (!SecRwLtStHeightChk_DW.UnitDelay_DSTATE)) || (rtb_RelationalOperator_j && (
    !SecRwLtStHeightChk_DW.UnitDelay1_DSTATE)) || (rtb_RelationalOperator_c && (
    !SecRwLtStHeightChk_DW.UnitDelay2_DSTATE))));

  /* Outputs for Enabled SubSystem: '<S3>/HeightCalcL' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  /* Logic: '<S7>/Logical Operator5' incorporates:
   *  Constant: '<S1>/PA_KeSMSeHeiCstTypeConfig_Val'
   *  Constant: '<S3>/ConfigVal'
   *  RelationalOperator: '<S7>/Relational Operator'
   */
  if ((0 == Rte_Prm_KeSMSeHeiCstTypeConfig_Val()) && rtb_LogicalOperator4) {
    /* MultiPortSwitch: '<S4>/Multiport Switch' incorporates:
     *  PreLookup: '<S4>/HdrstUpDwnTb1'
     *  PreLookup: '<S4>/HdrstUpDwnTb2'
     *  PreLookup: '<S4>/HdrstUpDwnTb3'
     *  PreLookup: '<S4>/HdrstUpDwnTb4'
     *  PreLookup: '<S4>/HdrstUpDwnTb5'
     *  PreLookup: '<S4>/HdrstUpDwnTb6'
     *  PreLookup: '<S4>/HdrstUpDwnTb7'
     *  PreLookup: '<S4>/Prelookup'
     *  SignalConversion: '<S1>/TmpLatchAtIfVeSMSuSecRwLtStBkReclnUpwdDnwdPos_Val_readOutport1'
     *  SignalConversion: '<S1>/TmpLatchAtIfVeSMSuSecRwLtStHdrstUpwdDnwdPos_Val_readOutport1'
     */
    switch (plook_u8u16_bincka(tmpRead,
             (Rte_Prm_KeSMSw4SAdpnReclnUpwdDnwdPos_Val()), 6U)) {
     case 0:
      SecRwLtStHeightChk_B.MultiportSwitch_i = plook_u8u16_bincka(tmpRead_0,
        (Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos1_Val()), 6U);
      break;

     case 1:
      SecRwLtStHeightChk_B.MultiportSwitch_i = plook_u8u16_bincka(tmpRead_0,
        (Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos2_Val()), 6U);
      break;

     case 2:
      SecRwLtStHeightChk_B.MultiportSwitch_i = plook_u8u16_bincka(tmpRead_0,
        (Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos3_Val()), 6U);
      break;

     case 3:
      SecRwLtStHeightChk_B.MultiportSwitch_i = plook_u8u16_bincka(tmpRead_0,
        (Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos4_Val()), 6U);
      break;

     case 4:
      SecRwLtStHeightChk_B.MultiportSwitch_i = plook_u8u16_bincka(tmpRead_0,
        (Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos5_Val()), 6U);
      break;

     case 5:
      SecRwLtStHeightChk_B.MultiportSwitch_i = plook_u8u16_bincka(tmpRead_0,
        (Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos6_Val()), 6U);
      break;

     default:
      SecRwLtStHeightChk_B.MultiportSwitch_i = plook_u8u16_bincka(tmpRead_0,
        (Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos7_Val()), 6U);
      break;
    }

    /* End of MultiPortSwitch: '<S4>/Multiport Switch' */
  }

  /* End of Logic: '<S7>/Logical Operator5' */
  /* End of Outputs for SubSystem: '<S3>/HeightCalcL' */

  /* Outputs for Enabled SubSystem: '<S3>/Subsystem3' incorporates:
   *  EnablePort: '<S9>/Enable'
   */
  /* Logic: '<S8>/Logical Operator5' incorporates:
   *  Constant: '<S1>/PA_KeSMSeHeiCstTypeConfig_Val'
   *  Constant: '<S3>/ConfigVal1'
   *  RelationalOperator: '<S8>/Relational Operator'
   */
  if ((1 == Rte_Prm_KeSMSeHeiCstTypeConfig_Val()) && rtb_LogicalOperator4) {
    /* PreLookup: '<S9>/Prelookup' incorporates:
     *  SignalConversion: '<S1>/TmpLatchAtIfVeSMSuSecRwLtStPassHeight_Val_readOutport1'
     */
    SecRwLtStHeightChk_B.Prelookup = plook_u8u8_binckag(tmpRead_2,
      (&(HeightIndexL[0])), 6U);
  }

  /* End of Logic: '<S8>/Logical Operator5' */
  /* End of Outputs for SubSystem: '<S3>/Subsystem3' */

  /* MultiPortSwitch: '<S5>/Multiport Switch' incorporates:
   *  Constant: '<S1>/PA_KeSMSeHeiCstTypeConfig_Val'
   */
  switch (Rte_Prm_KeSMSeHeiCstTypeConfig_Val()) {
   case 0:
    /* Outport: '<Root>/IfVeSMSuHeightIndexLt_Val'
     *
     * Block description for '<Root>/IfVeSMSuHeightIndexLt_Val':
     *  0��under 160
     *  1��160
     *  2��165
     *  3��170
     *  4��175
     *  5��180
     *  6��over 180
     */
    (void) Rte_Write_IfVeSMSuHeightIndexLt_Val
      (SecRwLtStHeightChk_B.MultiportSwitch_i);
    break;

   case 1:
    /* Outport: '<Root>/IfVeSMSuHeightIndexLt_Val'
     *
     * Block description for '<Root>/IfVeSMSuHeightIndexLt_Val':
     *  0��under 160
     *  1��160
     *  2��165
     *  3��170
     *  4��175
     *  5��180
     *  6��over 180
     */
    (void) Rte_Write_IfVeSMSuHeightIndexLt_Val(SecRwLtStHeightChk_B.Prelookup);
    break;

   case 2:
    /* Outport: '<Root>/IfVeSMSuHeightIndexLt_Val'
     *
     * Block description for '<Root>/IfVeSMSuHeightIndexLt_Val':
     *  0��under 160
     *  1��160
     *  2��165
     *  3��170
     *  4��175
     *  5��180
     *  6��over 180
     */
    (void) Rte_Write_IfVeSMSuHeightIndexLt_Val
      (SecRwLtStHeightChk_B.MultiportSwitch_i);
    break;

   default:
    /* Outport: '<Root>/IfVeSMSuHeightIndexLt_Val'
     *
     * Block description for '<Root>/IfVeSMSuHeightIndexLt_Val':
     *  0��under 160
     *  1��160
     *  2��165
     *  3��170
     *  4��175
     *  5��180
     *  6��over 180
     */
    (void) Rte_Write_IfVeSMSuHeightIndexLt_Val
      (SecRwLtStHeightChk_B.MultiportSwitch_i);
    break;
  }

  /* End of MultiPortSwitch: '<S5>/Multiport Switch' */

  /* Update for UnitDelay: '<S6>/Unit Delay' */
  SecRwLtStHeightChk_DW.UnitDelay_DSTATE = rtb_RelationalOperator_hy;

  /* Update for UnitDelay: '<S6>/Unit Delay1' */
  SecRwLtStHeightChk_DW.UnitDelay1_DSTATE = rtb_RelationalOperator_j;

  /* Update for UnitDelay: '<S6>/Unit Delay2' */
  SecRwLtStHeightChk_DW.UnitDelay2_DSTATE = rtb_RelationalOperator_c;

  /* End of Outputs for SubSystem: '<Root>/SecRwLtStHeightChk_Cal_sys' */
}

/* Model initialize function */
void SecRwLtStHeightChk_Init(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
