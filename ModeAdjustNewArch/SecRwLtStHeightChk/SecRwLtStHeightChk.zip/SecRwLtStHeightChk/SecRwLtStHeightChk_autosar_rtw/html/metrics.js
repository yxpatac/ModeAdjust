function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["Rte_Prm_KeSMSeHeiCstTypeConfig_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 1};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos1_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos2_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos3_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos4_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos5_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos6_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnHdrstUpwdDnwdPos7_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["Rte_Prm_KeSMSw4SAdpnReclnUpwdDnwdPos_Val_data"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	size: 14};
	 this.metricsArray.var["SecRwLtStHeightChk.c:HeightIndexL"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\SecRwLtStHeightChk.c",
	size: 7};
	 this.metricsArray.var["SecRwLtStHeightChk_B"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\SecRwLtStHeightChk.c",
	size: 2};
	 this.metricsArray.var["SecRwLtStHeightChk_DW"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\SecRwLtStHeightChk.c",
	size: 3};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSeHeiCstTypeConfig_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnHdrstUpwdDnwdPos1_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnHdrstUpwdDnwdPos2_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnHdrstUpwdDnwdPos3_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnHdrstUpwdDnwdPos4_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnHdrstUpwdDnwdPos5_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnHdrstUpwdDnwdPos6_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnHdrstUpwdDnwdPos7_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Prm_SecRwLtStHeightChk_KeSMSw4SAdpnReclnUpwdDnwdPos_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_SecRwLtStHeightChk_IfVeSMSuSecRwLtStBkReclnUpwdDnwdPos_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_SecRwLtStHeightChk_IfVeSMSuSecRwLtStHdrstUpwdDnwdPos_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_SecRwLtStHeightChk_IfVeSMSuSecRwLtStPassHeight_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_SecRwLtStHeightChk_StNumFlg_Is4s"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Read_SecRwLtStHeightChk_modestate32_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Rte_Write_SecRwLtStHeightChk_IfVeSMSuHeightIndexLt_Val"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\stub\\Rte_SecRwLtStHeightChk.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["SecRwLtStHeightChk_Cal"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\SecRwLtStHeightChk.c",
	stack: 13,
	stackTotal: 26};
	 this.metricsArray.fcn["SecRwLtStHeightChk_Init"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\SecRwLtStHeightChk_autosar_rtw\\SecRwLtStHeightChk.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["binsearch_u8u16"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\slprj\\autosar\\_sharedutils\\binsearch_u8u16.c",
	stack: 12,
	stackTotal: 12};
	 this.metricsArray.fcn["binsearch_u8u8"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\slprj\\autosar\\_sharedutils\\binsearch_u8u8.c",
	stack: 12,
	stackTotal: 12};
	 this.metricsArray.fcn["plook_u8u16_bincka"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\slprj\\autosar\\_sharedutils\\plook_u8u16_bincka.c",
	stack: 1,
	stackTotal: 13};
	 this.metricsArray.fcn["plook_u8u8_binckag"] = {file: "C:\\work\\MSM_558\\Model\\ModeAdjustNewArch\\SecRwLtStHeightChk\\slprj\\autosar\\_sharedutils\\plook_u8u8_binckag.c",
	stack: 1,
	stackTotal: 13};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="SecRwLtStHeightChk_metrics.html">Global Memory: 125(bytes) Maximum Stack: 13(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
